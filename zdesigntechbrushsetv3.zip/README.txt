________// _____-__+__// \_______. ________ _ \________

Thank you for downloading z-deisgn's brush set v3. 
z-design brush set v1 and v2 can be found on http://z-design.deviantart.com, more to come, so stay tuned.

Please give credit within your artwork or explanation. If you don't, others will know.. trust me.
For deviantart, use :iconz-design: somewhere within your explanations.

-----------------------------------------------

Instructions

1. Unzip(if you haven't already)
2. Put 'zdtech3.abr' into C:\Program Files\Adobe\Photoshop 7.0, CS, or CS2\Presets\Brushes\Adobe Photoshop only
3. Go to the brush panel(click brush tool, then click arrow in upper left hand corner), click the arrow within
the panel, then click load brushes, load zdtech3.abr.
4. USE it.
5. Make sure for credit, you may choose to notify me as well.




:) 


